export { default as SchoolProfile } from "./SchoolProfile";
