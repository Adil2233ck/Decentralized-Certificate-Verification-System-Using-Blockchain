import React from "react";
import "./Unauthorized.css";

const Unauthorized = () => {
  return (
    <div className="unauthorized-container">
      <h1 className="unauthorized-text">Unauthorized</h1>
    </div>
  );
};

export default Unauthorized;
